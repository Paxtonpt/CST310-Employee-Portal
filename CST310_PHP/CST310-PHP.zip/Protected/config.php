<?php
	define('DBHOST', 'localhost');
	define('DBNAME', 'cst310_steveon');
	define('DBUSER', 'root');
	define('DBPASS', 'Asdf1@34');
?>